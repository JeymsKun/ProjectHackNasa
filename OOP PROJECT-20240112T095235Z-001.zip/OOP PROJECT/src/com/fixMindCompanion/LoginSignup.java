package com.fixMindCompanion;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;


public class LoginSignup extends JFrame{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public LoginSignup() {
		initialize();
	}
	
	private void initialize() {
		
		setBounds(100, 100, 1366, 768);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		
		JLabel welcomeAddress = new JLabel("Welcome to MindCompanion");
		welcomeAddress.setFont(new Font("Tahoma", Font.BOLD, 15));
		welcomeAddress.setBounds(579, 400, 311, 35);
		add(welcomeAddress);
		
		JLabel showLogo = new JLabel("");
		showLogo.setHorizontalAlignment(SwingConstants.CENTER);
		showLogo.setIcon(new ImageIcon(getClass().getResource("/com/fixMindCompanion/1.png")));
		showLogo.setBounds(485, 10, 400, 400);
		add(showLogo);
		
		
		JButton loginButton = new JButton("LOGIN");
		loginButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		loginButton.setBounds(538, 500, 293, 35);
		add(loginButton);
		loginButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	loginWindow loginWindow = new loginWindow();
		        loginWindow.setVisible(true);
		    	
		    	dispose();
			}

			
        });

		
		JButton signupButton = new JButton("SIGNUP");
		signupButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		signupButton.setBounds(538, 550, 293, 35);
		add(signupButton);
		signupButton.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	signupWindow signup = new signupWindow();
		    	signup.setVisible(true);
		    	
		    	dispose();
            }

			
        });
		
		
	
		
	}
	
}
		
