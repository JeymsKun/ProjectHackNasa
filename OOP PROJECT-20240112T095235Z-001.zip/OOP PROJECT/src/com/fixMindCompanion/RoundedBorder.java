package com.fixMindCompanion;

import javax.swing.border.Border;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class RoundedBorder implements Border {
    private int radius;
    

    public RoundedBorder(int radius) {
        this.radius = radius;
    }

    @Override
    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        RoundRectangle2D shape = new RoundRectangle2D.Float(x, y, width - 1, height - 1, radius, radius);
        g2d.setColor(c.getBackground());
        g2d.fill(shape);

        g2d.setColor(c.getForeground());
        g2d.draw(shape);
    }

    @Override
    public Insets getBorderInsets(Component c) {
        return new Insets(this.radius, this.radius, this.radius, this.radius);
    }

    @Override
    public boolean isBorderOpaque() {
        return true;
    }

    public Insets getBorderInsets(Component c, Insets insets) {
        insets.top = this.radius;
        insets.left = this.radius;
        insets.bottom = this.radius;
        insets.right = this.radius;
        return insets;
    }
}