package com.fixMindCompanion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;


public class categoryContent1 extends JFrame{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	    public categoryContent1() {
	        initialize();
	    }

	    private void initialize() {

	        setBounds(100, 100, 755, 750);
	        setResizable(false);
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setLayout(null);
	        
	        JButton categoryButton1 = new JButton("");
	        categoryButton1.setBounds(190, 253, 114, 114);

	        JMenuBar menuBar = new JMenuBar();
	        JMenu menu = new JMenu("Menu");
	        menuBar.add(menu);

	        JMenuItem profileItem = new JMenuItem("Profile");
	        profileItem.setOpaque(true);
	        profileItem.setBackground(Color.BLACK);
	        profileItem.setForeground(Color.WHITE);
	        profileItem.setFont(new Font("Arial", Font.BOLD, 12));
	        menu.add(profileItem);
	        profileItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                
	            }
	        });

	        JMenuItem categoryItem = new JMenuItem("Category");
	        categoryItem.setOpaque(true);
	        categoryItem.setBackground(Color.BLACK);
	        categoryItem.setForeground(Color.WHITE);
	        categoryItem.setFont(new Font("Arial", Font.BOLD, 12));
	        menu.add(categoryItem);
	        categoryItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                
	            }
	        });

	        JMenuItem signOutItem = new JMenuItem("Sign Out");
	        signOutItem.setOpaque(true);
	        signOutItem.setBackground(Color.BLACK);
	        signOutItem.setForeground(Color.WHITE);
	        signOutItem.setFont(new Font("Arial", Font.BOLD, 12));
	        menu.add(signOutItem);
	        signOutItem.addActionListener(new ActionListener() {
	            @Override
	            public void actionPerformed(ActionEvent e) {
	                
	            }
	        });

	        setJMenuBar(menuBar);
	        setVisible(true);
	    
	    }
	        
	    

	    
      
}
        