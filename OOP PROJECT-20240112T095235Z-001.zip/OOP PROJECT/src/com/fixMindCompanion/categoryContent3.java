package com.fixMindCompanion;

import javax.swing.*;
import java.awt.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class categoryContent3 extends JFrame{
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public categoryContent3() {
		initialize();
	}
	
	private void initialize() {
		
        setBounds(100, 100, 755, 750);
        setResizable(false);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        
	}
}