package com.fixMindCompanion;

import java.awt.Font;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;



public class introduction1 extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel showLogo;
	private JLabel showLogoTitle;
	
	
	public introduction1() {
		initialize();
	}
	
	private void initialize() {
		setBounds(100, 100, 1366, 768);
		setResizable(false);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
		
		showLogoTitle = new JLabel("MindCompanion");
		showLogoTitle.setFont(new Font("Tahoma", Font.BOLD, 20));
		showLogoTitle.setBounds(600, 640, 293, 35);
		add(showLogoTitle);
		
		showLogo = new JLabel("");
		showLogo.setHorizontalAlignment(SwingConstants.CENTER);
		showLogo.setIcon(new ImageIcon(getClass().getResource("/com/fixMindCompanion/1.png")));
		showLogo.setBounds(485, 10, 400, 400);
		add(showLogo);
		
		// Schedule the transition to the next window after a delay
		Timer timer = new Timer();
	       timer.schedule(new TimerTask() {
	            public void run() {
	                showNextWindow();
	           }
	       }, 1000);
	}
	private void showNextWindow() {
        // Code to open the next window (e.g., LoginWindow)
        // Replace this with the actual code to open the next window
        LoginSignup login = new LoginSignup();
        login.setVisible(true);
        dispose();
    }

}
