package com.fixMindCompanion;

import javax.swing.SwingUtilities;

public class mainFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	        SwingUtilities.invokeLater(() -> {
	            try {
	                introduction1 intro = new introduction1();
	                intro.setVisible(true);
	            } catch (Exception e) {
	                e.printStackTrace();
	            }
	        });
	}


}
